$(document).ready(function () {
    $(document).click(function () {
        $('div').fadeOut('fast');
    });
});
